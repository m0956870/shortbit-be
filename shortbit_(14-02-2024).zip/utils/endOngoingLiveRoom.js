function endOngoingLiveRoom(rooRef) {
//if last time + 15 min < now ==> end


}

module.exports = endOngoingLiveRoom;
//script for when server restart then find all ongoing live room then call above function