const getBaseUrl = () => {
    return "http://143.110.245.179:8000";
}

module.exports = getBaseUrl;